CPPI <-> Joshua Project Cross-Reference File

The included CSV/Excel and Access files are a cross-reference between IMB CPPI (www.peoplegroups.org) people group data and Joshua Project (www.joshuaproject.net) people group data.  

The classifications are:

Type 1 - This people group is on both Joshua Project and CPPI
Type 2 - This people group is only on Joshua Project
Type 3 - This people group is only on CPPI

For further information contact info@joshuaproject.net 